<?php get_header(); ?>
  <main>
        <p><?php the_date(); ?></p>
        <p><?php the_category(); ?></p>
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
    </main>

<?php get_footer(); ?>
   