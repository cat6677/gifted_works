<?php get_header(); ?>
  <main>
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
    </main>

<?php get_footer(); ?>
   