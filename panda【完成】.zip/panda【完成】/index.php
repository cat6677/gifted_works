  <?php get_header(); ?>
  <main>
        <h2>タイトル</h2>
        <img src="<?php echo get_template_directory_uri(); ?>/img/gazou.jpg" alt="">
    </main>

<?php get_footer(); ?>
   