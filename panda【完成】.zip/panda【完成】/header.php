<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>クラシックテーマの作り方</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/common.css">
    <link rel="stylesheet" href="style.css">
    <?php wp_head(); ?>
</head>
<body>
    <header>
        <h1>クラシックテーマの作り方</h1>
    </header>