
<?php get_header(); ?>
    <main>
      <h2><?php the_title() ?></p>
      <p><?php the_content(); ?></p>
    </main>
    <div class="add">
        <h4>広告を入れることができます</h4>
    </div>
<?php get_footer(); ?>
    