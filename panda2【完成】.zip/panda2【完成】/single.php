<?php get_header(); ?>
    <main>
        <p><?php the_date(); ?></p>
      <p><?php the_title() ?></p>
      <p><?php the_content(); ?></p>
    </main>
<?php get_footer(); ?>
    